"""Test and debug scripts."""
