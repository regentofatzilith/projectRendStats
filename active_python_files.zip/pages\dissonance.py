"""Dissonance analysis page."""

import dash
from dash import html, dcc, callback, Input, Output
import dash_bootstrap_components as dbc
import pandas as pd
import math
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from functions import user_data_store
from functions.analysis import (
    format_dissonance_for_table,
    summarize_dissonance,
    compute_disco_boost_columns,
    build_maxed_disco_columns,
)
from functions.data import build_disco_tier_table, config
from functions.ui import warning_banner


dash.register_page(__name__, path="/dissonance", name="Dissonance", order=2)


layout = html.Div([
    html.H1("Dissonance", className="page-title"),
    html.P("Dissonance overview acccounts for the Dissonance Boost (Disco Boost) and the boost echoing from other Tiers with Disco Boost."),
    html.Ul("Optimized scenario assumes you can achieve your current max Disco Boost on every Tier easier than the Tier you achieved the max Disco Boost."),
    html.Ul("Lab+1 shows you the effect of your next Dissonant Echo lab level on your current and optimized boosts."),
    html.H2("Overview"),    
    html.Div(id="dissonance-warning"),
    dbc.Row(id="dissonance-summary", className="mb-3 g-2"),    
    html.Div(id="dissonance-matrix-graph"),
    html.H2("Tabular view"),
    dbc.Row([
        dbc.Col([
            html.Label("Display Mode"),
            html.Div([
                dcc.RadioItems(
                    id="dissonance-display-mode",
                    options=[
                        {"label": "Echo Boost per Tier", "value": "echo_per_tier"},
                        {"label": "Current Boost", "value": "current_boost"},
                        {"label": "Optimized Scenario", "value": "optimized_scenario"},
                    ],
                    value="current_boost",
                    labelStyle={"display": "inline-block", "marginRight": "1rem"},
                    inputStyle={"marginRight": "0.35rem"},
                    style={"display": "inline-block", "marginRight": "1rem"},
                ),
                dcc.Checklist(
                    id="dissonance-lab-plus-one",
                    options=[{"label": "Lab+1", "value": "lab_plus_one"}],
                    value=[],
                    labelStyle={"display": "inline-block", "marginRight": "0"},
                    inputStyle={"marginRight": "0.35rem"},
                    style={"display": "inline-block"},
                ),
            ], style={"display": "flex", "alignItems": "center", "gap": "0.75rem", "flexWrap": "wrap"}),
        ], width=12),
    ], className="mb-2"),
    html.Div(id="dissonance-tier-table"),
    html.Hr(),
    html.H2("Identified Dissonance Runs"),
    html.P("Identification is based on Run Notes in 'UserData.json'. Identifiers: The notes contain \"Attack Disco Run\", \"Defense Disco Run\", \"Utility Disco Run\", \"UW Disco Run\"."),
    html.Div(id="dissonance-table"),
])


_DISCO_ECHO_LAB_NAMES = {
    "attack":  "Dissonant Echo - Attack",
    "defense": "Dissonant Echo - Defense",
    "utility": "Dissonant Echo - Utility",
    "uw":      "Dissonant Echo - Ultimate Weapons",
}


@callback(
    Output("dissonance-warning", "children"),
    Output("dissonance-summary", "children"),
    Output("dissonance-matrix-graph", "children"),
    Output("dissonance-tier-table", "children"),
    Output("dissonance-table", "children"),
    Input("user-json-store", "data"),
    Input("dissonance-display-mode", "value"),
    Input("dissonance-lab-plus-one", "value"),
)

def update_dissonance(_user_json_state, display_mode, lab_plus_one_values):
    df = user_data_store.get_dissonance_runs()
    table_df = format_dissonance_for_table(df)
    tier_table = build_disco_tier_table(df)

    all_runs_df = user_data_store.cleaned.get("all_runs_time_series_df", pd.DataFrame())
    if not table_df.empty and isinstance(all_runs_df, pd.DataFrame) and not all_runs_df.empty:
        lookup_cols = ["timestamp", "tier", "wave", "real_time", "waves_per_hour"]
        if all(col in all_runs_df.columns for col in lookup_cols):
            lookup_df = all_runs_df[lookup_cols].copy()
            lookup_df["_join_timestamp"] = pd.to_datetime(
                lookup_df["timestamp"], errors="coerce", utc=True, format="mixed"
            )
            lookup_df["tier"] = lookup_df["tier"].astype(str)
            lookup_df["wave"] = pd.to_numeric(lookup_df["wave"], errors="coerce").fillna(0).astype(int)
            lookup_df = lookup_df.dropna(subset=["_join_timestamp"])
            lookup_df = lookup_df.drop_duplicates(subset=["_join_timestamp", "tier", "wave"], keep="first")

            table_df["_join_timestamp"] = pd.to_datetime(
                table_df["timestamp"], errors="coerce", utc=True, format="mixed"
            )
            table_df["tier"] = table_df["tier"].astype(str)
            table_df["wave"] = pd.to_numeric(table_df["wave"], errors="coerce").fillna(0).astype(int)

            table_df = table_df.merge(
                lookup_df[["_join_timestamp", "tier", "wave", "real_time", "waves_per_hour"]],
                on=["_join_timestamp", "tier", "wave"],
                how="left",
                suffixes=("", "_metrics"),
            )

            duration_from_metrics = pd.to_numeric(
                table_df["real_time"] if "real_time" in table_df.columns else pd.Series(index=table_df.index, dtype=float),
                errors="coerce",
            )
            existing_duration_blank = table_df["duration"].fillna("").astype(str).str.strip().eq("")
            table_df.loc[existing_duration_blank, "duration"] = duration_from_metrics.map(
                lambda x: "" if pd.isna(x) else f"{float(x):.2f}h"
            )

            table_df["waves_per_hour"] = pd.to_numeric(
                table_df["waves_per_hour_metrics"] if "waves_per_hour_metrics" in table_df.columns else pd.Series(index=table_df.index, dtype=float),
                errors="coerce",
            ).combine_first(
                pd.to_numeric(
                    table_df["waves_per_hour"] if "waves_per_hour" in table_df.columns else pd.Series(index=table_df.index, dtype=float),
                    errors="coerce",
                )
            )
            table_df["disco_5000_waves"] = 5000.0 / pd.to_numeric(table_df["waves_per_hour"], errors="coerce")
            table_df.loc[pd.to_numeric(table_df["waves_per_hour"], errors="coerce") <= 0, "disco_5000_waves"] = pd.NA
            table_df["disco_5000_waves"] = pd.to_numeric(table_df["disco_5000_waves"], errors="coerce").round(2)

            drop_cols = [col for col in ["_join_timestamp", "real_time", "waves_per_hour_metrics"] if col in table_df.columns]
            if drop_cols:
                table_df = table_df.drop(columns=drop_cols)

    if table_df.empty:
        return (
            warning_banner("No dissonance runs found for the current userData.json."),
            [],
            html.Div("No subplot data available.", style={"color": "#9ca3af"}),
            html.Div("No tier matrix available.", style={"color": "#9ca3af"}),
            html.Div("No rows to display.", style={"color": "#9ca3af"}),
        )

    summary = summarize_dissonance(table_df)
    table_display_df = table_df.copy()
    table_display_df["waves_per_hour"] = pd.to_numeric(
        table_display_df["waves_per_hour"] if "waves_per_hour" in table_display_df.columns else pd.Series(index=table_display_df.index, dtype=float),
        errors="coerce",
    ).map(lambda x: "" if pd.isna(x) else f"{float(x):.2f}")
    table_display_df["disco_5000_waves"] = pd.to_numeric(
        table_display_df["disco_5000_waves"] if "disco_5000_waves" in table_display_df.columns else pd.Series(index=table_display_df.index, dtype=float),
        errors="coerce",
    ).map(lambda x: "" if pd.isna(x) else f"{float(x):.2f}")

    runs_header_style = {
        "background": "#1e1b4b",
        "color": "#c4b5fd",
        "textAlign": "left",
        "border": "1px solid #312e81",
        "padding": "6px 8px",
        "fontWeight": "600",
    }
    runs_cell_style = {
        "border": "1px solid #2d2b50",
        "padding": "4px 8px",
        "color": "#e5e7eb",
        "fontSize": "0.9rem",
    }
    runs_rows = []
    for i, (_, row) in enumerate(table_display_df.reset_index(drop=True).iterrows()):
        bg = "#12111f" if i % 2 == 0 else "#1a1830"
        runs_rows.append(
            html.Tr([
                html.Td(str(row.get(col, "")), style={**runs_cell_style, "background": bg})
                for col in table_display_df.columns
            ])
        )

    table = dbc.Table(
        [
            html.Thead(html.Tr([html.Th(col, style=runs_header_style) for col in table_display_df.columns])),
            html.Tbody(runs_rows),
        ],
        bordered=False,
        size="sm",
        responsive=True,
        style={"borderCollapse": "collapse", "width": "100%"},
    )

    boost_df = compute_disco_boost_columns(tier_table)
    max_df = build_maxed_disco_columns(tier_table)
    merged = tier_table.merge(
        boost_df[[
            "tier",
            "attack_disco_boost",
            "defense_disco_boost",
            "utility_disco_boost",
            "uw_disco_boost",
            "attack_echo_boost",
            "defense_echo_boost",
            "utility_echo_boost",
            "uw_echo_boost",
        ]],
        on="tier",
        how="left",
    )
    merged = merged.merge(max_df, on="tier", how="left")

    # Fetch Dissonant Echo lab levels from userData
    labs_df = user_data_store.get_labs_all()
    def _lab_level(cat: str) -> int:
        if labs_df.empty or "name" not in labs_df.columns:
            return 0
        lab_name = _DISCO_ECHO_LAB_NAMES[cat]
        match = labs_df[labs_df["name"].str.strip() == lab_name]
        if match.empty:
            return 0
        raw = match.iloc[0].get("level", 0)
        try:
            return int(raw) if raw is not None else 0
        except (ValueError, TypeError):
            return 0

    def _echo_sum(frame: pd.DataFrame, col: str) -> float:
        if frame is None or frame.empty or col not in frame.columns:
            return 0.0
        return float(pd.to_numeric(frame[col], errors="coerce").fillna(0.0).sum())

    def _lab_plus_one_echo(echo_val: float, lab_level: int) -> float:
        # Next-level total echo from current total echo and current lab level.
        current_echo_lab_level = int(lab_level) + 1
        current_mult = current_echo_lab_level * 0.005
        next_mult = (current_echo_lab_level + 1) * 0.005
        if current_mult <= 0:
            return float(echo_val)
        return float(echo_val) / float(current_mult) * float(next_mult)

    category_labels = {
        "attack": "Attack",
        "defense": "Defense",
        "utility": "Utility",
        "uw": "UW",
    }
    category_metrics = {}
    for cat in ["attack", "defense", "utility", "uw"]:
        lab_lvl = _lab_level(cat)
        lab_echo_pct = (lab_lvl + 1) * 0.005
        current_echo = _echo_sum(boost_df, f"{cat}_echo_boost")
        maxed_echo = _echo_sum(max_df, f"max_{cat}_echo_boost")
        category_metrics[cat] = {
            "runs": int(summary.get(cat, 0)),
            "current_echo": current_echo,
            "maxed_echo": maxed_echo,
            "current_echo_lab1": _lab_plus_one_echo(current_echo, lab_lvl),
            "maxed_echo_lab1": _lab_plus_one_echo(maxed_echo, lab_lvl),
            "lab_level": lab_lvl,
            "lab_echo_pct": lab_echo_pct,
        }

    def _cap_for_category(cat: str) -> float:
        return 3.0 if cat == "utility" else 5.0

    def _mean_5000h_for_category(cat: str) -> float | None:
        if table_df.empty or "disco_type" not in table_df.columns:
            return None
        disco_series = table_df["disco_type"].astype(str).str.lower()
        if cat == "uw":
            mask = disco_series.str.contains("uw") | disco_series.str.contains("ultimate")
        else:
            mask = disco_series.str.contains(cat)
        vals = pd.to_numeric(
            table_df.loc[mask, "disco_5000_waves"] if "disco_5000_waves" in table_df.columns else pd.Series(dtype=float),
            errors="coerce",
        )
        if vals.empty or vals.notna().sum() == 0:
            return None
        return float(vals.mean())

    # Combined UW boost in echo-space: (1 + atk_echo) * (1 + uw_echo) - 1.
    atk = category_metrics["attack"]
    uw = category_metrics["uw"]
    combined_current = (1.0 + atk["current_echo"]) * (1.0 + uw["current_echo"]) - 1.0
    combined_current_l1 = (1.0 + atk["current_echo_lab1"]) * (1.0 + uw["current_echo_lab1"]) - 1.0
    combined_maxed = (1.0 + atk["maxed_echo"]) * (1.0 + uw["maxed_echo"]) - 1.0
    combined_maxed_l1 = (1.0 + atk["maxed_echo_lab1"]) * (1.0 + uw["maxed_echo_lab1"]) - 1.0

    # Best farming tier among tiers that actually have a utility disco run.
    coin_multiplier_by_tier = {}
    for tier_name, meta in config.TIER_CONFIG.items():
        if str(meta.get("type", "")).lower() != "farming":
            continue
        try:
            tier_num = int(str(tier_name).split(" ", 1)[1])
        except Exception:
            continue
        coin_multiplier_by_tier[f"{tier_num:02d}"] = float(meta.get("coin_multiplier", 0.0) or 0.0)

    utility_tiers = tier_table.copy()
    utility_tiers["utility_num"] = pd.to_numeric(
        utility_tiers["utility"] if "utility" in utility_tiers.columns else pd.Series(index=utility_tiers.index, dtype=float),
        errors="coerce",
    )
    utility_tiers = utility_tiers[utility_tiers["utility_num"].fillna(0) > 0].copy()
    utility_tiers["tier"] = utility_tiers["tier"].astype(str)
    utility_tiers["tier_coin_multiplier"] = utility_tiers["tier"].map(coin_multiplier_by_tier).fillna(0.0)

    best_tier_label = "N/A"
    tier_coin_mult = 0.0
    utility_disco_current = 1.0
    utility_disco_maxed = 1.0
    current_boosted_coin_mult = 0.0
    optimized_boosted_coin_mult = 0.0
    coin_increase_pct = 0.0

    utility_echo_current = float(category_metrics["utility"]["current_echo"])
    utility_echo_maxed = float(category_metrics["utility"]["maxed_echo"])

    if not utility_tiers.empty:
        candidates = []
        for _, cand in utility_tiers.iterrows():
            tier_code = str(cand.get("tier", ""))
            tier_mult = float(cand.get("tier_coin_multiplier", 0.0) or 0.0)
            merged_row = merged[merged["tier"].astype(str) == tier_code]
            if merged_row.empty:
                continue

            disco_cur = float(pd.to_numeric(pd.Series([merged_row.iloc[0].get("utility_disco_boost")]), errors="coerce").fillna(1.0).iloc[0])
            disco_max = float(pd.to_numeric(pd.Series([merged_row.iloc[0].get("max_utility_disco_boost")]), errors="coerce").fillna(1.0).iloc[0])
            cur_total_mult = (disco_cur + utility_echo_current) * tier_mult
            opt_total_mult = (disco_max + utility_echo_maxed) * tier_mult
            tier_num = pd.to_numeric(tier_code, errors="coerce")

            candidates.append({
                "tier": tier_code,
                "tier_num": float(tier_num) if pd.notna(tier_num) else -1.0,
                "tier_mult": tier_mult,
                "disco_cur": disco_cur,
                "disco_max": disco_max,
                "cur_total_mult": cur_total_mult,
                "opt_total_mult": opt_total_mult,
            })

        if candidates:
            best = max(candidates, key=lambda x: (x["cur_total_mult"], x["tier_num"]))
            best_tier_label = f"T{int(best['tier_num'])}" if best["tier_num"] >= 0 else str(best["tier"])
            tier_coin_mult = float(best["tier_mult"])
            utility_disco_current = float(best["disco_cur"])
            utility_disco_maxed = float(best["disco_max"])
            current_boosted_coin_mult = float(best["cur_total_mult"])
            optimized_boosted_coin_mult = float(best["opt_total_mult"])
            if current_boosted_coin_mult > 0:
                coin_increase_pct = (optimized_boosted_coin_mult / current_boosted_coin_mult - 1.0) * 100.0

    total_tiers = int(len(tier_table.index))
    category_card_stats = {}
    for cat in ["attack", "defense", "utility", "uw"]:
        cap = _cap_for_category(cat)
        cur_wave_col = cat
        cur_disco_col = f"{cat}_disco_boost"
        max_wave_col = f"max_{cat}_wave"
        max_disco_col = f"max_{cat}_disco_boost"

        cur_wave = pd.to_numeric(
            merged[cur_wave_col] if cur_wave_col in merged.columns else pd.Series(index=merged.index, dtype=float),
            errors="coerce",
        ).fillna(0.0)
        cur_disco = pd.to_numeric(
            merged[cur_disco_col] if cur_disco_col in merged.columns else pd.Series(index=merged.index, dtype=float),
            errors="coerce",
        ).fillna(1.0)
        max_wave = pd.to_numeric(
            merged[max_wave_col] if max_wave_col in merged.columns else pd.Series(index=merged.index, dtype=float),
            errors="coerce",
        ).fillna(0.0)
        max_disco = pd.to_numeric(
            merged[max_disco_col] if max_disco_col in merged.columns else pd.Series(index=merged.index, dtype=float),
            errors="coerce",
        ).fillna(1.0)

        maxed_runs = int(((cur_wave > 0) & (cur_disco >= (cap - 0.005))).sum())
        optimized_runs = int(((max_wave > 0) & (max_disco >= (cap - 0.005))).sum())
        avg_5000_h = _mean_5000h_for_category(cat)

        category_card_stats[cat] = {
            "maxed_runs": maxed_runs,
            "optimized_runs": optimized_runs,
            "avg_5000_h": avg_5000_h,
        }

    combined_maxed_runs = int(category_card_stats["attack"]["maxed_runs"] + category_card_stats["uw"]["maxed_runs"])
    combined_optimized_runs = int(category_card_stats["attack"]["optimized_runs"] + category_card_stats["uw"]["optimized_runs"])
    combined_total_tiers = total_tiers * 2

    attack_uw_mask = pd.Series(False, index=table_df.index)
    if "disco_type" in table_df.columns:
        dtypes = table_df["disco_type"].astype(str).str.lower()
        attack_uw_mask = dtypes.str.contains("attack") | dtypes.str.contains("uw") | dtypes.str.contains("ultimate")
    combined_avg_5000 = pd.to_numeric(
        table_df.loc[attack_uw_mask, "disco_5000_waves"] if "disco_5000_waves" in table_df.columns else pd.Series(dtype=float),
        errors="coerce",
    )
    combined_avg_5000_h = float(combined_avg_5000.mean()) if not combined_avg_5000.empty and combined_avg_5000.notna().sum() > 0 else None

    utility_lab_lvl = int(category_metrics["utility"]["lab_level"])
    utility_lab1_echo_pct = ((utility_lab_lvl + 2) * 0.5)
    current_boosted_coin_mult_lab1 = (utility_disco_current + category_metrics["utility"]["current_echo_lab1"]) * tier_coin_mult
    optimized_boosted_coin_mult_lab1 = (utility_disco_maxed + category_metrics["utility"]["maxed_echo_lab1"]) * tier_coin_mult

    summary_cards = []
    category_card_titles = {
        "attack": "Attack Boost",
        "uw": "UW Boost",
        "defense": "Defense Boost",
        "utility": "Utility Boost",
    }

    four_col_table_style = {
        "width": "100%",
        "borderCollapse": "collapse",
        "marginTop": "0.3rem",
    }
    four_col_label_cell = {
        "padding": "0",
        "paddingRight": "0.35rem",
        "verticalAlign": "top",
        "color": "#c4b5fd",
        "fontWeight": "600",
        "whiteSpace": "nowrap",
    }
    four_col_value_cell = {
        "padding": "0",
        "paddingRight": "0.9rem",
        "verticalAlign": "top",
        "color": "#e5e7eb",
        "whiteSpace": "nowrap",
    }

    def _four_col_row(
        left_label: str,
        left_value: str,
        right_label: str,
        right_value: str,
        *,
        left_label_style: dict | None = None,
        left_value_style: dict | None = None,
        right_label_style: dict | None = None,
        right_value_style: dict | None = None,
    ):
        return html.Tr([
            html.Td(left_label, style={**four_col_label_cell, **(left_label_style or {})}),
            html.Td(left_value, style={**four_col_value_cell, **(left_value_style or {})}),
            html.Td(right_label, style={**four_col_label_cell, **(right_label_style or {})}),
            html.Td(right_value, style={**four_col_value_cell, **(right_value_style or {})}),
        ])

    def _build_category_summary_card(cat: str) -> dbc.Col:
        m = category_metrics[cat]
        s = category_card_stats[cat]
        return dbc.Col(
            dbc.Card(dbc.CardBody([
                html.H6(category_card_titles[cat]),
                dbc.Row([
                    dbc.Col(
                        html.Div(
                            f"Maxed Disco Runs: {s['maxed_runs']}/{total_tiers}",
                            style={"fontWeight": "600", "color": "#c4b5fd", "marginTop": "0.1rem"},
                        ),
                        width=6,
                    ),
                    dbc.Col(
                        html.Div(
                            f"Optimized Runs: {s['maxed_runs']}/{s['optimized_runs']}",
                            style={"fontWeight": "600", "color": "#c4b5fd", "marginTop": "0.1rem", "textAlign": "right"},
                        ),
                        width=6,
                    ),
                ], className="g-0"),
                html.Div(
                    f"Avg. 5000 wave Duration: {s['avg_5000_h']:.2f} h" if s["avg_5000_h"] is not None else "Avg. 5000 wave Duration: n/a",
                    style={"color": "#e5e7eb", "marginTop": "0.1rem"},
                ),
                html.Table(
                    html.Tbody([
                        _four_col_row(
                            "Lab:",
                            f"Lvl {m['lab_level']} ({m['lab_echo_pct']*100:.1f}%)",
                            "Lab+1:",
                            f"Lvl {m['lab_level'] + 1} ({(m['lab_level'] + 2) * 0.5:.1f}%)",
                        ),
                        _four_col_row(
                            "Current Echo:",
                            f"{m['current_echo']:.2f}",
                            "Lab+1:",
                            f"{m['current_echo_lab1']:.2f}",
                            left_label_style={"color": "#e5e7eb", "fontWeight": "400"},
                            right_label_style={"color": "#e5e7eb", "fontWeight": "400"},
                        ),
                        _four_col_row(
                            "Optimized Echo:",
                            f"{m['maxed_echo']:.2f}",
                            "Lab+1:",
                            f"{m['maxed_echo_lab1']:.2f}",
                            left_label_style={"color": "#e5e7eb", "fontWeight": "400"},
                            right_label_style={"color": "#e5e7eb", "fontWeight": "400"},
                        ),
                    ]),
                    style=four_col_table_style,
                ),
            ])),
            width=12,
            md=6,
            lg=4,
        )

    summary_cards.append(_build_category_summary_card("attack"))
    summary_cards.append(_build_category_summary_card("uw"))

    summary_cards.append(
        dbc.Col(dbc.Card(dbc.CardBody([
            html.H6("Combined Attack & UW Boost"),
            dbc.Row([
                dbc.Col(
                    html.Div(
                        f"Maxed Disco Runs: {combined_maxed_runs}/{combined_total_tiers}",
                        style={"fontWeight": "600", "color": "#c4b5fd", "marginTop": "0.1rem"},
                    ),
                    width=6,
                ),
                dbc.Col(
                    html.Div(
                        f"Optimized Runs: {combined_maxed_runs}/{combined_optimized_runs}",
                        style={"fontWeight": "600", "color": "#c4b5fd", "marginTop": "0.1rem", "textAlign": "right"},
                    ),
                    width=6,
                ),
            ], className="g-0"),
            html.Div(
                f"Avg. 5000 wave Duration: {combined_avg_5000_h:.2f} h" if combined_avg_5000_h is not None else "Avg. 5000 wave Duration: n/a",
                style={"color": "#e5e7eb", "marginTop": "0.1rem"},
            ),
            html.Table(
                html.Tbody([
                    _four_col_row(
                        "Attack Lab:",
                        f"Lvl {atk['lab_level']} ({atk['lab_echo_pct']*100:.1f}%)",
                        "Lab+1:",
                        f"Lvl {atk['lab_level'] + 1} ({(atk['lab_level'] + 2) * 0.5:.1f}%)",
                    ),
                    _four_col_row(
                        "UW Lab:",
                        f"Lvl {uw['lab_level']} ({uw['lab_echo_pct']*100:.1f}%)",
                        "Lab+1:",
                        f"Lvl {uw['lab_level'] + 1} ({(uw['lab_level'] + 2) * 0.5:.1f}%)",
                    ),
                    _four_col_row(
                        "Current Echo:",
                        f"{combined_current:.2f}",
                        "Lab+1:",
                        f"{combined_current_l1:.2f}",
                        left_label_style={"color": "#e5e7eb", "fontWeight": "400"},
                        right_label_style={"color": "#e5e7eb", "fontWeight": "400"},
                    ),
                    _four_col_row(
                        "Optimized Echo:",
                        f"{combined_maxed:.2f}",
                        "Lab+1:",
                        f"{combined_maxed_l1:.2f}",
                        left_label_style={"color": "#e5e7eb", "fontWeight": "400"},
                        right_label_style={"color": "#e5e7eb", "fontWeight": "400"},
                    ),
                ]),
                style=four_col_table_style,
            ),
        ])), width=12, md=6, lg=4),
    )

    summary_cards.append(_build_category_summary_card("defense"))
    summary_cards.append(_build_category_summary_card("utility"))

    best_farming_summary_card = dbc.Col(dbc.Card(dbc.CardBody([
        html.H6("Utility Boost - Match Best Farming Tier"),
        html.Div(best_tier_label, style={"fontWeight": "700", "color": "#c4b5fd", "fontSize": "1.8rem"}),
        html.Div(
            "Multiplier: (1 + Disco Boost) x Tier Difficulty",
            style={"color": "#e5e7eb", "marginTop": "0.15rem"},
        ),
        html.Table(
            html.Tbody([
                _four_col_row(
                    "Utility Lab:",
                    f"Lvl {utility_lab_lvl} ({category_metrics['utility']['lab_echo_pct']*100:.1f}%)",
                    "Lab+1:",
                    f"Lvl {utility_lab_lvl + 1} ({utility_lab1_echo_pct:.1f}%)",
                ),
                _four_col_row(
                    "Current Mult:",
                    f"{current_boosted_coin_mult:.2f}",
                    "Lab+1:",
                    f"{current_boosted_coin_mult_lab1:.2f}",
                    left_label_style={"color": "#e5e7eb", "fontWeight": "400"},
                    right_label_style={"color": "#e5e7eb", "fontWeight": "400"},
                ),
                _four_col_row(
                    "Optimized Mult:",
                    f"{optimized_boosted_coin_mult:.2f}",
                    "Lab+1:",
                    f"{optimized_boosted_coin_mult_lab1:.2f}",
                    left_label_style={"color": "#e5e7eb", "fontWeight": "400"},
                    right_label_style={"color": "#e5e7eb", "fontWeight": "400"},
                ),
            ]),
            style={**four_col_table_style, "marginTop": "0.2rem"},
        ),
    ])), width=12, md=6, lg=4)

    summary_cards.append(best_farming_summary_card)

    def _to_tier_code(value: object) -> str:
        raw = str(value or "").strip().lower().replace("tier", "").replace("t", "")
        num = pd.to_numeric(pd.Series([raw]), errors="coerce").iloc[0]
        if pd.isna(num):
            return ""
        return f"{int(float(num)):02d}"

    def _match_wave_from_disco(disco_val: float) -> int:
        d = float(disco_val)
        if d <= 1.0:
            return 0
        if d >= 3.0:
            return 5000
        wave_est = 5000.0 * (((d - 1.0) / (3.0 - 1.0)) ** (1.0 / 1.75))
        return int(math.ceil(wave_est))

    # Keep chart tier order stable and numeric-first.
    merged["_tier_num"] = pd.to_numeric(merged["tier"], errors="coerce")
    merged = merged.sort_values(["_tier_num", "tier"], na_position="last").reset_index(drop=True)

    selected_mode = str(display_mode or "current_boost")
    use_lab_plus_one = "lab_plus_one" in list(lab_plus_one_values or [])
    CATEGORIES = ["attack", "defense", "utility", "uw"]

    def _series_value(row: pd.Series, key: str, default: float) -> float:
        return float(pd.to_numeric(pd.Series([row.get(key)]), errors="coerce").fillna(default).iloc[0])

    def _wave_label(row: pd.Series, key: str) -> str:
        w = pd.to_numeric(pd.Series([row.get(key)]), errors="coerce").fillna(0.0).iloc[0]
        w_int = int(float(w))
        return f"{w_int:04d}" if w_int > 0 else "0000"

    # Build chart data per category.
    tiers = merged["tier"].astype(str).tolist()
    chart_series = {}
    for cat in CATEGORIES:
        lab_level = int(category_metrics.get(cat, {}).get("lab_level", 0))
        total_current_echo = float(category_metrics.get(cat, {}).get("current_echo", 0.0))
        total_maxed_echo = float(category_metrics.get(cat, {}).get("maxed_echo", 0.0))
        total_current_echo_l1 = _lab_plus_one_echo(total_current_echo, lab_level)
        total_maxed_echo_l1 = _lab_plus_one_echo(total_maxed_echo, lab_level)

        act_disco = []
        act_echo = []
        act_echo_l1 = []
        max_disco = []
        max_echo = []
        max_echo_l1 = []
        act_wave = []
        max_wave = []

        for _, row in merged.iterrows():
            d_cur = _series_value(row, f"{cat}_disco_boost", 1.0)
            d_max = _series_value(row, f"max_{cat}_disco_boost", 1.0)

            # Effective echo = total echo - this tier's own echo (a tier's echo doesn't boost itself).
            tier_echo_cur = _series_value(row, f"{cat}_echo_boost", 0.0)
            tier_echo_max = _series_value(row, f"max_{cat}_echo_boost", 0.0)
            eff_echo = max(0.0, total_current_echo - tier_echo_cur)
            eff_echo_l1 = _lab_plus_one_echo(eff_echo, lab_level)
            eff_maxed_echo = max(0.0, total_maxed_echo - tier_echo_max)
            eff_maxed_echo_l1 = _lab_plus_one_echo(eff_maxed_echo, lab_level)

            act_disco.append(d_cur)
            act_echo.append(eff_echo)
            act_echo_l1.append(eff_echo_l1)
            max_disco.append(d_max)
            max_echo.append(eff_maxed_echo)
            max_echo_l1.append(eff_maxed_echo_l1)
            act_wave.append(_wave_label(row, cat))
            max_wave.append(_wave_label(row, f"max_{cat}_wave"))

        chart_series[cat] = {
            "actual_disco": act_disco,
            "actual_echo": act_echo,
            "actual_echo_lab1": act_echo_l1,
            "maxed_disco": max_disco,
            "maxed_echo": max_echo,
            "maxed_echo_lab1": max_echo_l1,
            "actual_wave": act_wave,
            "maxed_wave": max_wave,
        }

    fig = make_subplots(
        rows=2,
        cols=3,
        subplot_titles=(
            "Attack Boost",
            "UW Boost",
            "Combined Attack & UW Boost",
            "Defense Boost",
            "Utility Boost",
            "Utility Boost - Match Best Farming Tier",
        ),
        specs=[[{}, {}, {}], [{}, {}, {}]],
        horizontal_spacing=0.06,
        vertical_spacing=0.16,
    )

    subplot_positions = {
        "attack": (1, 1),
        "uw": (1, 2),
        "attack_uw": (1, 3),
        "defense": (2, 1),
        "utility": (2, 2),
        "best_farming_match": (2, 3),
    }
    trace_colors = {
        "actual_disco": "#0ea5e9",
        "actual_echo": "#22c55e",
        "actual_echo_lab1": "#ec4899",
        "maxed_disco": "#1e3a8a",
        "maxed_echo": "#166534",
        "maxed_echo_lab1": "#ec4899",
        "best_match": "#fbbf24",
        "best_match_impossible": "#7f1d1d",
    }

    y_axis_ceiling = {}

    def _snap_ceil(max_val: float) -> float:
        """Round max_val up to the next logarithmic tick mark."""
        mval = max(float(max_val), 1.0)
        k = int(math.floor(math.log10(mval)))
        decade = 10.0 ** k
        normalized = mval / decade
        mul = 0.1 if normalized <= 1.0 else (0.5 if normalized <= 5.0 else 1.0)
        step = mul * decade
        return max(2.0, step * math.ceil(mval / step))

    # Add derived combined subplot: attack x uw disco with combined echo totals.
    attack_series = chart_series.get("attack", {})
    uw_series = chart_series.get("uw", {})
    chart_series["attack_uw"] = {
        "actual_disco": [
            a * u for a, u in zip(
                attack_series.get("actual_disco", []),
                uw_series.get("actual_disco", []),
            )
        ],
        "actual_echo": [combined_current] * len(tiers),
        "actual_echo_lab1": [combined_current_l1] * len(tiers),
        "maxed_disco": [
            a * u for a, u in zip(
                attack_series.get("maxed_disco", []),
                uw_series.get("maxed_disco", []),
            )
        ],
        "maxed_echo": [combined_maxed] * len(tiers),
        "maxed_echo_lab1": [combined_maxed_l1] * len(tiers),
    }

    # Build best farming matching subplot series.
    utility_series = chart_series.get("utility", {})
    utility_actual_disco = utility_series.get("actual_disco", [1.0] * len(tiers))
    utility_maxed_disco = utility_series.get("maxed_disco", [1.0] * len(tiers))
    coin_mult_per_tier = [coin_multiplier_by_tier.get(t, 0.0) for t in tiers]
    best_tier_code = ""
    if str(best_tier_label).startswith("T"):
        best_tier_code = _to_tier_code(best_tier_label)
    required_match_disco = []
    required_match_impossible_disco = []
    required_match_wave = []
    required_match_impossible_wave = []
    best_tier_highlight = []
    for tier_code, tier_mult in zip(tiers, coin_mult_per_tier):
        if tier_mult > 0 and current_boosted_coin_mult > 0:
            req = (current_boosted_coin_mult / tier_mult) - utility_echo_current
            if req > 3.0:
                required_match_disco.append(float("nan"))
                required_match_impossible_disco.append(req)
                required_match_wave.append("")
                required_match_impossible_wave.append("not possible")
            else:
                req_clamped = max(1.0, req)
                required_match_disco.append(req_clamped)
                required_match_impossible_disco.append(float("nan"))
                required_match_wave.append(f"{_match_wave_from_disco(req_clamped):04d}")
                required_match_impossible_wave.append("")
        else:
            required_match_disco.append(float("nan"))
            required_match_impossible_disco.append(float("nan"))
            required_match_wave.append("")
            required_match_impossible_wave.append("")
        best_tier_highlight.append(utility_disco_current if tier_code == best_tier_code else 0.0)

    chart_series["best_farming_match"] = {
        "actual_disco": utility_actual_disco,
        "maxed_disco": utility_maxed_disco,
        "required_match_disco": required_match_disco,
        "required_match_impossible_disco": required_match_impossible_disco,
        "required_match_wave": required_match_wave,
        "required_match_impossible_wave": required_match_impossible_wave,
        "best_tier_highlight": best_tier_highlight,
    }

    CHART_KEYS = ["attack", "defense", "utility", "uw", "attack_uw", "best_farming_match"]
    for cat in CHART_KEYS:
        r, c = subplot_positions[cat]
        is_base_subplots = cat in CATEGORIES
        if cat == "uw":
            cap = "UW"
        elif cat == "attack_uw":
            cap = "Combined Attack & UW"
        elif cat == "best_farming_match":
            cap = "Utility Boost - Match Best Farming Tier"
        else:
            cap = cat.capitalize()

        # Build four visual levels:
        # L1 front  : Actual Disco (solid)
        # L2 behind : Actual Total Echo (solid)
        # L3 behind : Maxed Disco (outline only)
        # L4 back   : Maxed Total Echo (outline only)
        # Lab+1     : dotted lines
        if cat == "best_farming_match":
            level0_coin_mult = None
            level1_actual = chart_series[cat]["actual_disco"]
            level2_actual = chart_series[cat]["best_tier_highlight"]
            level3_maxed = chart_series[cat]["maxed_disco"]
            level4_maxed = [0.0] * len(tiers)
            level5_actual_lab1 = [0.0] * len(tiers)
            line_maxed_lab1 = chart_series[cat]["required_match_disco"]
            level_required_impossible = chart_series[cat]["required_match_impossible_disco"]
            achieved_wave_labels = chart_series.get("utility", {}).get("actual_wave", [""] * len(tiers))
            needed_wave_labels = chart_series.get("utility", {}).get("maxed_wave", [""] * len(tiers))
            line_required_wave = chart_series[cat]["required_match_wave"]
            line_required_impossible_wave = chart_series[cat]["required_match_impossible_wave"]
            level_required_impossible_base = [
                max(a, m) for a, m in zip(level1_actual, level3_maxed)
            ]
        else:
            level0_coin_mult = None
            level1_actual = chart_series[cat]["actual_disco"]
            level2_actual = [
                d + e for d, e in zip(
                    chart_series[cat]["actual_disco"],
                    chart_series[cat]["actual_echo"],
                )
            ]
            level3_maxed = chart_series[cat]["maxed_disco"]
            level4_maxed = [
                d + e for d, e in zip(
                    chart_series[cat]["maxed_disco"],
                    chart_series[cat]["maxed_echo"],
                )
            ]
            level5_actual_lab1 = [
                d + e for d, e in zip(
                    chart_series[cat]["actual_disco"],
                    chart_series[cat]["actual_echo_lab1"],
                )
            ]
            line_maxed_lab1 = [
                d + e for d, e in zip(
                    chart_series[cat]["maxed_disco"],
                    chart_series[cat]["maxed_echo_lab1"],
                )
            ]
            level_required_impossible = [float("nan")] * len(tiers)
            line_required_wave = [""] * len(tiers)
            line_required_impossible_wave = [""] * len(tiers)
            level_required_impossible_base = [float("nan")] * len(tiers)
            achieved_wave_labels = chart_series.get(cat, {}).get("actual_wave", [""] * len(tiers))
            needed_wave_labels = chart_series.get(cat, {}).get("maxed_wave", [""] * len(tiers))

        wave_achieved_suffix = "<br>Wave Achieved: %{customdata}" if is_base_subplots else ""
        wave_needed_suffix = "<br>Wave Needed: %{customdata}" if is_base_subplots else ""

        max_candidates = [
            float(v)
            for v in (level1_actual + level2_actual + level3_maxed + level4_maxed + level5_actual_lab1 + line_maxed_lab1)
            if pd.notna(v)
        ]
        max_val = max(max_candidates) if max_candidates else 1.0
        ceil_val = 3.5 if cat == "best_farming_match" else _snap_ceil(max_val)
        y_axis_ceiling[cat] = ceil_val

        if level0_coin_mult is not None:
            fig.add_trace(
                go.Bar(
                    x=tiers,
                    y=level0_coin_mult,
                    name="Tier Coin Multiplier",
                    marker={"color": "rgba(148,163,184,0.35)"},
                    hovertemplate=f"{cap} Tier %{{x}}<br>Tier Coin Multiplier: %{{y:.3f}}<extra></extra>",
                    legendgroup="coin_mult_only",
                    showlegend=False,
                    opacity=1.0,
                ),
                row=r,
                col=c,
            )

        if cat != "best_farming_match":
            # Level 5 back-most: actual total echo Lab+1 (muted theoretical)
            fig.add_trace(
                go.Bar(
                    x=tiers,
                    y=level5_actual_lab1,
                    customdata=(achieved_wave_labels if is_base_subplots else None),
                    name="Current Disco + Echo Boost (Lab+1)",
                    marker={"color": trace_colors["actual_echo_lab1"]},
                    hovertemplate=f"{cap} Tier %{{x}}<br>Current Disco + Echo Boost (Lab+1): %{{y:.3f}}<extra></extra>",
                    legendgroup="actual_echo_lab1",
                    showlegend=(cat == "attack"),
                    legendrank=3,
                    opacity=0.25,
                ),
                row=r,
                col=c,
            )

        if cat != "best_farming_match":
            # Level 4: maxed total echo (muted theoretical)
            fig.add_trace(
                go.Bar(
                    x=tiers,
                    y=level4_maxed,
                    customdata=(needed_wave_labels if is_base_subplots else None),
                    name="Maxed Disco + Echo Boost",
                    marker={"color": trace_colors["maxed_echo"]},
                    hovertemplate=f"{cap} Tier %{{x}}<br>Maxed Disco + Echo Boost: %{{y:.3f}}<extra></extra>",
                    legendgroup="maxed_echo",
                    showlegend=(cat == "attack"),
                    legendrank=5,
                    opacity=0.35,
                ),
                row=r,
                col=c,
            )
        # Level 3: maxed disco (muted theoretical)
        fig.add_trace(
            go.Bar(
                x=tiers,
                y=level3_maxed,
                customdata=(needed_wave_labels if (is_base_subplots or cat == "best_farming_match") else None),
                name=("Maxed Disco Boost" if cat != "best_farming_match" else "Maxed Utility Boost"),
                marker={"color": trace_colors["maxed_disco"]},
                hovertemplate=(
                    f"{cap} Tier %{{x}}<br>"
                    f"{'Maxed Disco Boost' if cat != 'best_farming_match' else 'Maxed Utility Boost'}: %{{y:.3f}}"
                    f"{wave_needed_suffix if cat != 'best_farming_match' else '<br>Wave Needed: %{customdata}'}"
                    "<extra></extra>"
                ),
                legendgroup="maxed_disco",
                showlegend=(cat == "attack"),
                legendrank=4,
                opacity=0.45,
            ),
            row=r,
            col=c,
        )
        if cat == "best_farming_match":
            required_custom = [
                [boost, wave]
                for boost, wave in zip(line_maxed_lab1, line_required_wave)
            ]
            fig.add_trace(
                go.Bar(
                    x=tiers,
                    y=line_maxed_lab1,
                    customdata=required_custom,
                    name="Boost Needed To Match Best Farming Tier",
                    marker={"color": trace_colors["best_match"]},
                    hovertemplate=(
                        f"{cap} Tier %{{x}}<br>"
                        f"Target (Disco Boost x Difficulty Tier): {current_boosted_coin_mult:.3f}"
                        "<br>Required Boost: %{customdata[0]:.3f}"
                        "<br>Required Wave: %{customdata[1]}<extra></extra>"
                    ),
                    legendgroup="best_match_req",
                    showlegend=False,
                    opacity=0.28,
                ),
                row=r,
                col=c,
            )
            impossible_cap_height = [
                max(0.0, 3.5 - b) if pd.notna(v) else float("nan")
                for v, b in zip(level_required_impossible, level_required_impossible_base)
            ]
            impossible_custom = [
                [boost, wave]
                for boost, wave in zip(level_required_impossible, line_required_impossible_wave)
            ]
            fig.add_trace(
                go.Bar(
                    x=tiers,
                    y=impossible_cap_height,
                    base=level_required_impossible_base,
                    customdata=impossible_custom,
                    name="Parity to Best Farming Tier not possible",
                    marker={"color": trace_colors["best_match_impossible"]},
                    hovertemplate=(
                        f"{cap} Tier %{{x}}<br>"
                        f"Target (Disco Boost x Difficulty Tier): {current_boosted_coin_mult:.3f}"
                        "<br>Required Boost: %{customdata[0]:.3f}"
                        "<br>Required Wave: not possible (max 3.00x Disco Boost)<extra></extra>"
                    ),
                    legendgroup="best_match_impossible",
                    showlegend=False,
                    opacity=0.30,
                ),
                row=r,
                col=c,
            )
        if cat != "best_farming_match":
            # Level 2: actual total echo (solid factual)
            fig.add_trace(
                go.Bar(
                    x=tiers,
                    y=level2_actual,
                    customdata=(achieved_wave_labels if is_base_subplots else None),
                    name="Current Disco + Echo Boost",
                    marker={"color": trace_colors["actual_echo"]},
                    hovertemplate=f"{cap} Tier %{{x}}<br>Current Disco + Echo Boost: %{{y:.3f}}<extra></extra>",
                    legendgroup="actual_echo",
                    showlegend=(cat == "attack"),
                    legendrank=2,
                    opacity=0.85,
                ),
                row=r,
                col=c,
            )
        # Level 1 front: actual disco (solid factual)
        fig.add_trace(
            go.Bar(
                x=tiers,
                y=level1_actual,
                customdata=(achieved_wave_labels if (is_base_subplots or cat == "best_farming_match") else None),
                name=("Current Disco Boost" if cat != "best_farming_match" else "Current Utility Boost"),
                marker={"color": trace_colors["actual_disco"]},
                hovertemplate=(
                    f"{cap} Tier %{{x}}<br>"
                    f"{'Current Disco Boost' if cat != 'best_farming_match' else 'Current Utility Boost'}: %{{y:.3f}}"
                    f"{wave_achieved_suffix if cat != 'best_farming_match' else '<br>Wave Achieved: %{customdata}'}"
                    "<extra></extra>"
                ),
                legendgroup="actual_disco",
                showlegend=(cat == "attack" if cat != "best_farming_match" else False),
                legendrank=1,
                opacity=0.95,
            ),
            row=r,
            col=c,
        )

        if cat == "best_farming_match":
            fig.add_trace(
                go.Bar(
                    x=tiers,
                    y=level2_actual,
                    name="Best Farming Tier",
                    marker={"color": trace_colors["best_match"]},
                    customdata=(achieved_wave_labels if cat == "best_farming_match" else None),
                    hovertemplate=(
                        f"{cap} Tier %{{x}}<br>"
                        f"Best Tier Multiplier (Disco Boost x Difficulty Tier): {current_boosted_coin_mult:.3f}"
                        "<br>Current Disco Boost: %{y:.3f}"
                        "<br>Wave Achieved: %{customdata}<extra></extra>"
                    ),
                    legendgroup="best_farming_tier",
                    showlegend=False,
                    opacity=0.95,
                ),
                row=r,
                col=c,
            )

        # Maxed Lab+1 as dotted hull line
        if cat != "best_farming_match":
            fig.add_trace(
                go.Scatter(
                    x=tiers,
                    y=line_maxed_lab1,
                    customdata=(needed_wave_labels if is_base_subplots else None),
                    mode="lines",
                    name="Maxed Disco + Echo Boost (Lab+1)",
                    line={"color": trace_colors["maxed_echo_lab1"], "width": 2, "dash": "dot"},
                    hovertemplate=f"{cap} Tier %{{x}}<br>Maxed Disco + Echo Boost (Lab+1): %{{y:.3f}}<extra></extra>",
                    legendgroup="maxed_echo_lab1",
                    showlegend=(cat == "attack"),
                    legendrank=6,
                ),
                row=r,
                col=c,
            )

    def _tick_step_from_max(max_val: float) -> float:
        """Dynamic step size from max value.

        Formula:
          step = m * 10^k
          where k = floor(log10(max_val))
          and m in {0.1, 0.5, 1.0} chosen by normalized max in that decade.

        This yields:
          max<=5 -> 0.5, max<=10 -> 1, max<=50 -> 5, max<=100 -> 10, ...
        """
        mval = max(float(max_val), 1.0)
        k = int(math.floor(math.log10(mval)))
        decade = 10.0 ** k
        normalized = mval / decade
        if normalized <= 1.0:
            mul = 0.1
        elif normalized <= 5.0:
            mul = 0.5
        else:
            mul = 1.0
        return mul * decade

    def _log_ticks_from_max(max_val: float):
        step = _tick_step_from_max(max_val)
        mval = max(float(max_val), 1.0)
        lower = 1.0

        ticks = [lower]
        v = step
        while v <= mval:
            ticks.append(round(v, 10))
            v += step
        ticks.append(mval)

        ticks = sorted({t for t in ticks if t > 0})
        labels = [str(int(t)) if abs(t - round(t)) < 1e-9 else f"{t:.2f}".rstrip("0").rstrip(".") for t in ticks]
        return ticks, labels, lower

    # Logarithmic scale with variable-resolution ticks per subplot.
    for cat in CHART_KEYS:
        r, c = subplot_positions[cat]
        max_tick = float(y_axis_ceiling.get(cat, 10))
        tick_vals, tick_text, lower_tick = _log_ticks_from_max(max_tick)
        axis_range = [0, math.log10(3.5)] if cat == "best_farming_match" else [0, math.log10(max_tick)]

        fig.update_yaxes(
            type="log",
            tickmode="array",
            tickvals=tick_vals,
            ticktext=tick_text,
            range=axis_range,
            gridcolor="rgba(255,255,255,0.16)",
            zeroline=False,
            title_text=("Boost from Disco + Echo" if c == 1 else None),
            row=r,
            col=c,
        )
        fig.update_xaxes(
            title_text="Tier",
            showgrid=False,
            tickangle=-40,
            row=r,
            col=c,
        )

    fig.update_layout(
        template="plotly_dark",
        barmode="overlay",
        paper_bgcolor="#0b0f19",
        plot_bgcolor="#0f172a",
        margin={"l": 30, "r": 20, "t": 56, "b": 30},
        legend={"orientation": "h", "yanchor": "bottom", "y": 1.08, "x": 0.0},
        height=860,
        title=None,
    )

    # Dark theme colour palette
    _C = {
        "bg_header":  "#1e1b4b",   # deep indigo header
        "bg_even":    "#12111f",   # very dark row (even tiers)
        "bg_odd":     "#1a1830",   # slightly lighter row (odd tiers)
        "border":     "#312e81",   # indigo border between tiers
        "cell_border":"#2d2b50",   # faint inner border
        "label":      "#6b7280",   # muted grey for "Tier/Wave/Boost" labels
        "tier_num":   "#e5e7eb",   # bright white-grey for tier number
        "wave":       "#a78bfa",   # purple for wave values
        "boost":      "#f9fafb",   # near-white for boost values
        "boost_max":  "#fbbf24",   # gold for capped boosts
        "dash":       "#4b5563",   # dim dash for empty cells
        "sim_wave":   "#9ca3af",   # light grey for simulated wave values
        "sim_boost":  "#d1d5db",   # light grey for simulated boost values
        "simulated":  "#38bdf8",   # bright blue for simulated maxed values
    }

    def _row_bg(tier_label: str):
        try:
            n = int(tier_label)
        except ValueError:
            n = 0
        return _C["bg_even"] if n % 2 == 0 else _C["bg_odd"]

    def _wave_cell(category: str, row: pd.Series, bg: str) -> html.Td:
        actual_wave_raw = row.get(category)
        actual_wave_num = pd.to_numeric(pd.Series([actual_wave_raw]), errors="coerce").fillna(0.0).iloc[0]
        has_logged_run = int(float(actual_wave_num)) > 0

        wave_col = category if selected_mode in {"echo_per_tier", "current_boost"} else f"max_{category}_wave"
        wave_raw = row.get(wave_col)
        wave_num = pd.to_numeric(pd.Series([wave_raw]), errors="coerce").fillna(0.0).iloc[0]
        wave_int = int(float(wave_num))
        if wave_int > 0:
            content = str(wave_int)
            if selected_mode == "optimized_scenario" and not has_logged_run:
                color = _C["label"]
            else:
                color = _C["wave"]
        else:
            content = "---"
            color = _C["label"]
        return html.Td(content, style={
            "color": color, "textAlign": "center",
            "background": bg, "border": f"1px solid {_C['cell_border']}",
            "padding": "2px 8px",
            "fontStyle": "normal",
        })

    def _boost_cell(category: str, row: pd.Series, bg: str) -> html.Td:
        is_optimized = selected_mode == "optimized_scenario"

        actual_wave_raw = row.get(category)
        actual_wave_num = pd.to_numeric(pd.Series([actual_wave_raw]), errors="coerce").fillna(0.0).iloc[0]
        has_logged_run = int(float(actual_wave_num)) > 0

        wave_col = category if selected_mode in {"echo_per_tier", "current_boost"} else f"max_{category}_wave"
        wave_raw = row.get(wave_col)
        wave_num = pd.to_numeric(pd.Series([wave_raw]), errors="coerce").fillna(0.0).iloc[0]
        wave_int = int(float(wave_num))
        has_data = wave_int > 0

        disco_key = f"max_{category}_disco_boost" if is_optimized else f"{category}_disco_boost"
        disco_raw = row.get(disco_key)
        disco_val = float(pd.to_numeric(pd.Series([disco_raw]), errors="coerce").fillna(1.0).iloc[0])
        if not has_data:
            disco_val = 1.0

        echo_key = f"max_{category}_echo_boost" if is_optimized else f"{category}_echo_boost"
        echo_raw = row.get(echo_key)
        tier_echo_val = float(pd.to_numeric(pd.Series([echo_raw]), errors="coerce").fillna(0.0).iloc[0])
        lab_level = int(category_metrics.get(category, {}).get("lab_level", 0))
        if use_lab_plus_one:
            tier_echo_val = _lab_plus_one_echo(tier_echo_val, lab_level)

        total_echo_key = "maxed_echo_lab1" if is_optimized and use_lab_plus_one else (
            "maxed_echo" if is_optimized else ("current_echo_lab1" if use_lab_plus_one else "current_echo")
        )
        total_echo_val = float(category_metrics.get(category, {}).get(total_echo_key, 0.0))
        effective_echo_val = max(0.0, total_echo_val - tier_echo_val)

        bonus_cap = 3.0 if category == "utility" else 5.0
        at_cap = disco_val >= bonus_cap - 0.005

        if selected_mode == "echo_per_tier":
            text = f"x{tier_echo_val:.3f}"
        else:
            text = f"x{disco_val:.3f} / +{effective_echo_val:.3f}"

        if not has_data:
            color = _C["label"]
        elif is_optimized and not has_logged_run:
            color = _C["label"]
        else:
            color = _C["boost_max"] if at_cap else _C["boost"]

        return html.Td(text, style={
            "textAlign": "center",
            "fontWeight": "700" if at_cap else "400",
            "color": color,
            "background": bg,
            "border": f"1px solid {_C['cell_border']}",
            "padding": "2px 8px",
            "fontStyle": "normal",
        })

    body_rows = []
    for _, row in merged.iterrows():
        tier_label = str(row.get("tier", ""))
        bg = _row_bg(tier_label)
        tier_border = f"2px solid {_C['border']}"

        wave_row_style = {"borderTop": tier_border, "borderBottom": "none"}
        boost_row_style = {"borderBottom": f"1px solid {_C['cell_border']}"}

        tier_cell = html.Td(
            [html.Div("Tier", style={"fontSize": "0.65rem", "color": _C["label"]}),
             html.Div(tier_label, style={"fontSize": "1.1rem", "fontWeight": "700", "color": _C["tier_num"]})],
            rowSpan=2,
            style={
                "verticalAlign": "middle", "width": "4rem",
                "background": bg, "borderTop": tier_border,
                "borderRight": f"1px solid {_C['border']}",
                "padding": "4px 10px",
            },
        )
        label_style = {"color": _C["label"], "fontSize": "0.72rem",
                       "background": bg, "border": f"1px solid {_C['cell_border']}",
                       "padding": "2px 6px", "width": "3.5rem"}

        body_rows.append(html.Tr(
            [tier_cell, html.Td("Wave", style=label_style)]
            + [_wave_cell(c, row, bg) for c in CATEGORIES],
            style=wave_row_style,
        ))
        body_rows.append(html.Tr(
            [html.Td("Boost", style=label_style)]
            + [_boost_cell(c, row, bg) for c in CATEGORIES],
            style=boost_row_style,
        ))

    th_style = {"background": _C["bg_header"], "color": "#c4b5fd",
                "textAlign": "center", "border": f"1px solid {_C['border']}",
                "padding": "6px 8px", "fontWeight": "600"}

    combined_table = dbc.Table(
        [
            html.Thead(html.Tr([
                html.Th("Tier", style={**th_style, "width": "4rem", "textAlign": "left"}),
                html.Th("", style={**th_style, "width": "3.5rem"}),
                html.Th("Attack", style=th_style),
                html.Th("Defense", style=th_style),
                html.Th("Utility", style=th_style),
                html.Th("UW", style=th_style),
            ])),
            html.Tbody(body_rows),
        ],
        bordered=False,
        size="sm",
        responsive=True,
        style={"borderCollapse": "collapse", "width": "100%"},
    )

    matrix_graph = html.Div([
        html.H2("Total Dissonance Boosts - Graphical Overview"),        
        dcc.Graph(
            id="dissonance-echo-subplots",
            figure=fig,
            config={"displaylogo": False},
            style={"marginBottom": "1rem"},
        ),
    ])

    return None, summary_cards, matrix_graph, combined_table, table
